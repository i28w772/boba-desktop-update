import { useEffect, useState } from 'react'

/**
 * Tracks the rendered width of a DOM element via ResizeObserver.
 * Used to scale fixed-size game canvases down to fit phone screens.
 */
export function useContainerWidth(ref) {
  const [width, setWidth] = useState(0)

  useEffect(() => {
    const el = ref.current
    if (!el) return

    setWidth(el.clientWidth)

    if (typeof ResizeObserver === 'undefined') return
    const ro = new ResizeObserver((entries) => {
      const w = entries[0]?.contentRect?.width
      if (w) setWidth(w)
    })
    ro.observe(el)
    return () => ro.disconnect()
  }, [ref])

  return width
}
