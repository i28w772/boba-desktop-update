import { useCallback, useEffect, useState } from 'react'
import { detectDevice } from './device.js'

function isStandalone() {
  return (
    window.matchMedia?.('(display-mode: standalone)').matches ||
    window.navigator.standalone === true
  )
}

/**
 * Wraps the browser's beforeinstallprompt flow (Chrome/Edge/Android) plus
 * detection for platforms — like iOS Safari — that don't support it and
 * need the manual "Add to Home Screen" instructions instead.
 */
export function useInstallPrompt() {
  const [deferredEvent, setDeferredEvent] = useState(null)
  const [installed, setInstalled] = useState(() => isStandalone())
  const [isIOS, setIsIOS] = useState(false)

  useEffect(() => {
    const onBeforeInstall = (e) => {
      e.preventDefault()
      setDeferredEvent(e)
    }
    const onInstalled = () => {
      setInstalled(true)
      setDeferredEvent(null)
    }

    window.addEventListener('beforeinstallprompt', onBeforeInstall)
    window.addEventListener('appinstalled', onInstalled)

    const { deviceType } = detectDevice()
    setIsIOS(deviceType === 'iPad' || deviceType === 'iPhone')

    return () => {
      window.removeEventListener('beforeinstallprompt', onBeforeInstall)
      window.removeEventListener('appinstalled', onInstalled)
    }
  }, [])

  const promptInstall = useCallback(async () => {
    if (!deferredEvent) return 'unavailable'
    deferredEvent.prompt()
    const choice = await deferredEvent.userChoice
    setDeferredEvent(null)
    if (choice.outcome === 'accepted') setInstalled(true)
    return choice.outcome
  }, [deferredEvent])

  return {
    canInstall: Boolean(deferredEvent),
    installed,
    isIOS,
    promptInstall,
  }
}
