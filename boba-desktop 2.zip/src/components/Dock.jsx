import { motion, AnimatePresence } from 'framer-motion'
import BobaLogo from './BobaLogo.jsx'
import soundManager from '../utils/soundManager.js'

export default function Dock({ minimized, onRestore }) {
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-4 flex justify-center z-40">
      <motion.div
        layout
        className="pointer-events-auto glass rounded-2xl px-3 py-2 flex items-end gap-3 shadow-soft glow-border"
      >
        <AnimatePresence>
          {minimized && (
            <motion.button
              key="minimized-icon"
              initial={{ opacity: 0, y: 30, scale: 0.6 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: 30, scale: 0.6 }}
              whileHover={{ y: -8 }}
              onClick={() => {
                soundManager.maximize()
                onRestore()
              }}
              className="relative flex flex-col items-center justify-center h-12 w-12 rounded-xl bg-milk/70 border border-white/50 shadow-soft"
              title="Restore BobaOS"
            >
              <BobaLogo size={26} />
              <span className="absolute -bottom-1.5 h-1.5 w-1.5 rounded-full bg-matcha" />
            </motion.button>
          )}
        </AnimatePresence>

        {/* Decorative resident dock icons for that native-desktop feel */}
        {['🍵', '🍡', '🧋', '🍮'].map((emoji, i) => (
          <motion.div
            key={emoji}
            whileHover={{ y: -8, scale: 1.1 }}
            className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/40 border border-white/40 text-lg cursor-default"
            title="Just here for ambience"
          >
            {emoji}
          </motion.div>
        ))}
      </motion.div>
    </div>
  )
}
