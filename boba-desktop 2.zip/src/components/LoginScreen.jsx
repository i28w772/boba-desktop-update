import { useState } from 'react'
import { motion } from 'framer-motion'
import BobaLogo from './BobaLogo.jsx'
import soundManager from '../utils/soundManager.js'

export const AVATAR_COLORS = [
  { id: 'matcha', hex: '#8CA779', label: 'Matcha' },
  { id: 'taro', hex: '#B39CD0', label: 'Taro' },
  { id: 'milk', hex: '#D9B98A', label: 'Milk Tea' },
  { id: 'blush', hex: '#F3C9D4', label: 'Blush' },
  { id: 'pearl', hex: '#4A3324', label: 'Pearl' },
]

export default function LoginScreen({ onSubmit }) {
  const [name, setName] = useState('')
  const [color, setColor] = useState(AVATAR_COLORS[0].id)

  const handleSubmit = (e) => {
    e.preventDefault()
    const trimmed = name.trim()
    if (!trimmed) return
    soundManager.success()
    onSubmit({ name: trimmed, color })
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 12, scale: 0.97 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, y: -12, scale: 0.97 }}
      className="flex flex-col items-center gap-5 glass rounded-3xl p-8 shadow-soft glow-border w-[320px] max-w-full mx-auto"
    >
      <BobaLogo size={48} spin />
      <div className="text-center">
        <h2 className="font-display text-lg font-semibold text-pearl">Welcome to BobaOS</h2>
        <p className="text-xs text-pearl/60 mt-1">What should we call you?</p>
      </div>

      <form onSubmit={handleSubmit} className="w-full flex flex-col gap-4">
        <input
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Your name"
          maxLength={18}
          autoFocus
          className="w-full px-4 py-2.5 rounded-full bg-white/70 border border-white/60 text-sm text-pearl placeholder:text-pearl/40 focus:outline-none focus:ring-2 focus:ring-matcha transition"
        />

        <div>
          <p className="text-[11px] text-pearl/50 mb-2 text-center">Pick a cup color</p>
          <div className="flex justify-center gap-2.5">
            {AVATAR_COLORS.map((c) => (
              <button
                type="button"
                key={c.id}
                onClick={() => {
                  soundManager.hover()
                  setColor(c.id)
                }}
                aria-label={c.label}
                className={`h-9 w-9 rounded-full border-2 transition-transform ${
                  color === c.id ? 'border-pearl scale-110' : 'border-white/60'
                }`}
                style={{ background: c.hex }}
              />
            ))}
          </div>
        </div>

        <button
          type="submit"
          disabled={!name.trim()}
          className="w-full py-2.5 rounded-full bg-matcha text-white font-semibold text-sm shadow-soft disabled:opacity-40 disabled:cursor-not-allowed hover:brightness-105 active:scale-95 transition"
        >
          Enter the café
        </button>
      </form>
    </motion.div>
  )
}
