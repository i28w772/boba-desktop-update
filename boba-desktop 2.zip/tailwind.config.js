/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        cream: '#FBF2E4',
        milk: '#EEDFC2',
        'milk-dark': '#DEC79E',
        matcha: {
          DEFAULT: '#8CA779',
          light: '#B7CBA3',
          dark: '#5E7A4C',
        },
        taro: {
          DEFAULT: '#B39CD0',
          light: '#D8C9E9',
          dark: '#8467A8',
        },
        pearl: {
          DEFAULT: '#4A3324',
          light: '#6B4A34',
        },
        blush: '#F3C9D4',
      },
      fontFamily: {
        display: ['"Fredoka"', 'sans-serif'],
        body: ['"Quicksand"', 'sans-serif'],
        mono: ['"JetBrains Mono"', 'monospace'],
      },
      boxShadow: {
        glow: '0 0 24px rgba(179, 156, 208, 0.35)',
        'glow-matcha': '0 0 24px rgba(140, 167, 121, 0.35)',
        soft: '0 8px 30px rgba(74, 51, 36, 0.12)',
      },
      backdropBlur: {
        xs: '2px',
      },
      keyframes: {
        rise: {
          '0%': { transform: 'translateY(0)', opacity: '0.9' },
          '100%': { transform: 'translateY(-140px)', opacity: '0' },
        },
        wobble: {
          '0%, 100%': { transform: 'rotate(-2deg)' },
          '50%': { transform: 'rotate(2deg)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-200% 0' },
          '100%': { backgroundPosition: '200% 0' },
        },
      },
      animation: {
        rise: 'rise 3.2s ease-in infinite',
        wobble: 'wobble 2.4s ease-in-out infinite',
        shimmer: 'shimmer 2.5s linear infinite',
      },
    },
  },
  plugins: [],
}
